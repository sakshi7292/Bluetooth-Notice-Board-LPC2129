.\delays.o: delays.c
.\delays.o: C:\Keil\ARM\Inc\Philips\LPC21xx.H
