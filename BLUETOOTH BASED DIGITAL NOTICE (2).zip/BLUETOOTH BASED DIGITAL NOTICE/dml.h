void display_char(unsigned char ch,unsigned int delay);
void display_4char(unsigned char *ch4,unsigned int delay);
void scroll_string(unsigned char *str,unsigned int speed);
