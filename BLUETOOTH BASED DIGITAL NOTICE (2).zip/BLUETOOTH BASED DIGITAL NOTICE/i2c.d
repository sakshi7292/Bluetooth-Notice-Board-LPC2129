.\i2c.o: i2c.c
.\i2c.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
.\i2c.o: types.h
.\i2c.o: delays.h
.\i2c.o: i2c_defines.h
