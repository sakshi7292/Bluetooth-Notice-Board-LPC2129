void Init_Timer0(void);   // must be called once before delay_us/delay_ms are used
void delay_us(unsigned int dlyUS);
void delay_ms(unsigned int dlyMS);
void delay_s(unsigned int dlyS);
