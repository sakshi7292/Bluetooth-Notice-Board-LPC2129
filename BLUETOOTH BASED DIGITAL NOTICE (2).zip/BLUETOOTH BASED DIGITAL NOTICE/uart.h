#ifndef __UART_H__
#define __UART_H__

void InitUART0(void);
void UART0_Tx(unsigned char ch);



#endif
