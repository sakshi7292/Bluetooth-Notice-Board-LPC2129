.\dml.o: dml.c
.\dml.o: C:\Keil\ARM\Inc\Philips\LPC21xx.H
.\dml.o: delays.h
.\dml.o: defines.h
.\dml.o: 74LS164.h
.\dml.o: dml.h
